package com.library.student.action;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.library.student.dao.BookDao;
import com.library.student.dao.ObtainDao;
import com.library.student.dao.StuDao;
import com.library.student.domain.Book;
import com.library.student.domain.Obtain;
import com.library.student.domain.Student;

@Controller
public class FileAction {

    @Autowired
    private BookDao bookDao;
    @Autowired
    private StuDao stuDao;
    @Autowired
    private ObtainDao obtainDao;

    @GetMapping("/")
    public String getMainDashboard(Model model) {
    	model.addAttribute("book", new Book());
        model.addAttribute("bookList", bookDao.findAll());
        return "book.jsp";
    }

    @GetMapping("/book")
    public String book(Model model) {
        model.addAttribute("book", new Book());
        model.addAttribute("bookList", bookDao.findAll());
        return "book.jsp";
    }

    @GetMapping("/student")
    public String student(Model model) {
        model.addAttribute("student", new Student());
        model.addAttribute("studentList", stuDao.findAll());
        return "student.jsp";
    }

    @GetMapping("/obtain")
    public String obtain(Model model) {
        model.addAttribute("obtain", new Obtain());
        model.addAttribute("obtainList", obtainDao.findAll());
        model.addAttribute("books", bookDao.findAll());
        model.addAttribute("students", stuDao.findAll());
        return "obtain.jsp";
    }

    @GetMapping("/return")
    public String returnBook(Model model) {
        model.addAttribute("obtain", new Obtain());
        model.addAttribute("obtainList", obtainDao.findAll());
        model.addAttribute("books", bookDao.findAll());
        model.addAttribute("students", stuDao.findAll());
        return "return.jsp";
    }

    @GetMapping("/bookObtainReport")
    public String getBookObtainReport(Model model) {
        model.addAttribute("books", bookDao.findAll());
        model.addAttribute("students", stuDao.findAll());
        return "reports/bookObtainReport.jsp";
    }
    @GetMapping("/fineReport")
    public String getFineDtort(Model model) {
        model.addAttribute("books", bookDao.findAll());
        model.addAttribute("students", stuDao.findAll());
        return "reports/fineReport.jsp";
    }

}
