package com.library.student.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.library.student.db.Db;
import com.library.student.domain.Book;

@Component
public class BookDao {

	@Autowired
	private Db db;
	
    public List<Book> findAll() {
        String sql = "SELECT * FROM book"; 
        Connection conn = db.getConnection();
        Statement statement;
        List<Book> bookList = new ArrayList<Book>();
        try {
            statement = conn.createStatement();
            ResultSet result = statement.executeQuery(sql);
            while (result.next()) {
                Book book = new Book();
                book.setBookno(result.getLong("bookno"));
                book.setTitle(result.getString("title"));
                book.setAuthname(result.getString("authname"));
                book.setYear(result.getInt("year"));
                book.setPublisher(result.getString("publisher"));
                book.setType(result.getString("type"));
                book.setPrice(result.getString("price"));
                bookList.add(book);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return bookList;
    }

    public void save(Book book) {
    	Connection conn = db.getConnection();
        String sql = "INSERT INTO book  (`bookno`, `title`, `authname`, `year`, `publisher`, `type`, `price` ) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try {  
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setLong(1, book.getBookno());
            statement.setString(2, book.getTitle());
            statement.setString(3, book.getAuthname());
            statement.setInt(4, book.getYear());
            statement.setString(5, book.getPublisher());
            statement.setString(6, book.getType());
            statement.setString(7, book.getPrice());
            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("A new Book inserted successfully!");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void update(Book book) {
    	String sql = "UPDATE book SET title=?, authname=?, year=? , publisher=?, type=?, price=? WHERE bookno=?";
        Connection conn = db.getConnection();
        PreparedStatement statement;
        try { 
            statement = conn.prepareStatement(sql);
            statement.setString(1, book.getTitle());
            statement.setString(2, book.getAuthname());
            statement.setInt(3, book.getYear());
            statement.setString(4, book.getPublisher());
            statement.setString(5, book.getType());
            statement.setString(6, book.getPrice());
            statement.setLong(7, book.getBookno());
            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("An existing book was updated successfully!");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean existsById(Long bookno) {
        String sql = "SELECT * FROM book where bookno = " + bookno + "";
        Connection conn = db.getConnection();
        Statement statement;
        try {
            statement = conn.createStatement();
            ResultSet result = statement.executeQuery(sql);
            while (result.next()) {
                if (result.getString(1).isEmpty()) {
                    return false;
                } else {
                    return true;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public void deleteById(Long id) {
    	Connection conn = db.getConnection();
        String sql = "DELETE FROM book WHERE bookno=?";
        try {
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setLong(1, id);
            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Book Deleted successfully!");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String count() {
        String sql = "SELECT count(*) FROM book ";
        Connection conn = db.getConnection();
        Statement statement;
        try {
            statement = conn.createStatement();
            ResultSet result = statement.executeQuery(sql);
            while (result.next()) {
                if (result.getString("count(*)").isEmpty()) {
                    return result.getString("count(*)");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "0";
    }
} 
