/**
 *
 */
package com.library.student.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.library.student.db.Db;
import com.library.student.domain.Obtain;
import com.library.student.dto.ObtainDto;


@Component
public class ObtainDao {
 
	@Autowired
	private Db db;

    public List<Obtain> findAll() {
        String sql = " SELECT * from obtain; "; 
        Connection conn = db.getConnection();
        Statement statement;
        List<Obtain> obtainList = new ArrayList<Obtain>();
        try {
            statement = conn.createStatement();
            ResultSet result = statement.executeQuery(sql);
            while (result.next()) {
                Obtain obtain = new Obtain();
                obtain.setId(result.getLong("id"));
                obtain.setObtaindate(result.getString("obtaindate"));
                obtain.setDuedate(result.getString("duedate"));
                obtain.setReturneddate(result.getString("returneddate"));
                obtain.setFine(result.getString("fine"));
                obtain.setStuid(result.getString("stuid")); 
                obtain.setBookid(result.getString("bookid")); 
                obtainList.add(obtain);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return obtainList;
    }


    public void save(Obtain obtain) {
		 Connection conn = db.getConnection();
	     String sql = "INSERT INTO obtain  ( `obtaindate`, `duedate`, `returneddate`, `fine`, `stuid`, `bookid`) VALUES ( ?, ?, ?, ?, ?, ?)";
        try { 
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, obtain.getObtaindate());
            statement.setString(2, obtain.getDuedate());
            statement.setString(3, obtain.getReturneddate());
            statement.setString(4, obtain.getFine());
            statement.setString(5, obtain.getStuid());
            statement.setString(6, obtain.getBookid());
            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("A new Obtain inserted successfully!");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void update(Obtain obtain) {
    	 String sql = "UPDATE obtain SET obtaindate=?, duedate=?, returneddate=? , fine=?, stuid=?, bookid=? WHERE id=?";
         Connection conn = db.getConnection();
         PreparedStatement statement;
        try { 
            statement = conn.prepareStatement(sql);
            statement.setString(1, obtain.getObtaindate());
            statement.setString(2, obtain.getDuedate());
            statement.setString(3, obtain.getReturneddate());
            statement.setString(4, obtain.getFine());
            statement.setString(5, obtain.getStuid());
            statement.setString(6, obtain.getBookid());
            statement.setLong(7, obtain.getId());
            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("An existing obtain was updated successfully!");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean existsById(Long id) {
        String sql = "SELECT * FROM obtain where id = " + id + "";
        Connection conn = db.getConnection();
        Statement statement;
        try {
            statement = conn.createStatement();
            ResultSet result = statement.executeQuery(sql);
            while (result.next()) {
                if (result.getString(1).isEmpty()) {
                    return false;
                } else {
                    return true;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public ObtainDto findById(Long id) {
        String sql = "SELECT * FROM obtain where id = " + id + " LIMIT 1 ";
        Connection conn = db.getConnection();
        Statement statement;
        ObtainDto obtain = new ObtainDto();
        try {
            statement = conn.createStatement();
            ResultSet result = statement.executeQuery(sql);
            while (result.next()) {
                obtain.setId(result.getLong("id"));
                obtain.setObtaindate(result.getString("obtaindate"));
                obtain.setDuedate(result.getString("duedate"));
                obtain.setReturneddate(result.getString("returneddate"));
                obtain.setFine(result.getString("fine"));
                obtain.setStuid(result.getString("stuid"));
                obtain.setStuname(result.getString("stuname"));
                obtain.setBookid(result.getString("bookid"));
                obtain.setBookname(result.getString("bookname"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return obtain;
    }

    public void deleteById(Long id) {
    	Connection conn = db.getConnection();
        String sql = "DELETE FROM obtain WHERE id=?";
        try {
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setLong(1, id);
            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Obtain Deleted successfully!");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<ObtainDto> getSearchData(String start, String end, String bookId, String stuid) {
    	String sql = " SELECT obtain.*, student.name AS studentname, book.title AS bookname FROM obtain " + 
    			" INNER JOIN student ON obtain.stuid = student.stuid INNER JOIN book ON obtain.bookid = book.bookno " + 
    			" WHERE obtaindate BETWEEN '" + start + "' AND '" + end + "' AND obtain.bookid LIKE '" + bookId + "' AND obtain.stuid LIKE '" + stuid + "'  "; 
        Connection conn = db.getConnection();
        Statement statement;
        List<ObtainDto> obtainList = new ArrayList<ObtainDto>();
        try {
            statement = conn.createStatement();
            ResultSet result = statement.executeQuery(sql);
            while (result.next()) {
                ObtainDto obtain = new ObtainDto();
                obtain.setId(result.getLong("id"));
                obtain.setObtaindate(result.getString("obtaindate"));
                obtain.setDuedate(result.getString("duedate"));
                obtain.setReturneddate(result.getString("returneddate"));
                obtain.setFine(result.getString("fine"));
                obtain.setStuid(result.getString("stuid"));
                obtain.setStuname(result.getString("studentname"));
                obtain.setBookid(result.getString("bookid"));
                obtain.setBookname(result.getString("bookname"));
                obtainList.add(obtain);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return obtainList;
    } 

}
