package com.library.student.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Data;

@Entity
@Data
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long stuid;
    private String name;
    private Integer age;
    private String section; 
    private String idnumber; 
    private String gender;
    private String email;
    private String contactno;
    private String address;
 
}
