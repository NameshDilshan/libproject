package com.library.student.action;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.library.student.dao.ObtainDao;
import com.library.student.domain.Obtain;

@Controller
public class ObtainAction {

    @Autowired
    private ObtainDao obtainDao;

    @PostMapping("/saveObtainData")
    public String saveObtainData(@ModelAttribute("obtain") Obtain obtain, Model model) {
        if (obtainDao.existsById(obtain.getId())) {
        	obtainDao.update(obtain);
        } else {
        	obtainDao.save(obtain);
        }
        if (obtain.getReturneddate() != null) {
            return "redirect:/return";
        }
        return "redirect:/obtain";
    }

    @DeleteMapping("/obtains/{id}")
    @ResponseBody
    public Boolean deleteObtain(@PathVariable(value = "id") Long id, Model model) {
        if (obtainDao.existsById(id)) {
        	obtainDao.deleteById(id);
            System.out.println(" Obtain Deleted Successfully  ID : " + id);
            return Boolean.TRUE;
        }
        return Boolean.FALSE;
    }

}
