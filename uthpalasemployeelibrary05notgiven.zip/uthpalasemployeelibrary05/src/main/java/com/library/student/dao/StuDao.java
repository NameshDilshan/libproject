package com.library.student.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.library.student.db.Db;
import com.library.student.domain.Student;

@Component
public class StuDao {

	public List<Student> findAll() {
		String sql = "SELECT * FROM student";
		Db db = new Db();
		Connection conn = db.getConnection();
		Statement statement;
		List<Student> studentList = new ArrayList<Student>();
		try {
			statement = conn.createStatement();
			ResultSet result = statement.executeQuery(sql);
			while (result.next()) {
				Student student = new Student();
				student.setStuid(result.getLong("stuid"));
				student.setName(result.getString("name"));
				student.setAge(result.getInt("age"));
				student.setSection(result.getString("section"));
				student.setIdnumber(result.getString("idnumber"));
				student.setGender(result.getString("gender"));
				student.setEmail(result.getString("email"));
				student.setContactno(result.getString("contactno"));
				student.setAddress(result.getString("address"));
				studentList.add(student);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return studentList;
	}

	public void save(Student student) {
		try {
			Db db = new Db();
			Connection conn = db.getConnection();
			String sql = "INSERT INTO student (`stuid`,`name`,`age`,`section`, `idnumber`,`gender`,`email`,`contactno`, `address`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
			PreparedStatement statement = conn.prepareStatement(sql);
			statement.setLong(1, student.getStuid());
			statement.setString(2, student.getName());
			statement.setInt(3, student.getAge());
			statement.setString(4, student.getSection()); 
			statement.setString(5, student.getIdnumber());
			statement.setString(6, student.getGender());
			statement.setString(7, student.getEmail());
			statement.setString(8, student.getContactno());
			statement.setString(9, student.getAddress());
			int rowsInserted = statement.executeUpdate();
			if (rowsInserted > 0) {
				System.out.println("A new Emp inserted successfully!");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void update(Student student) {
		try {
			String sql = "UPDATE student SET name=?, age=?, section=? , idnumber=?, gender=?, email=?, contactno=?, address=?  WHERE stuid=?";
			Db db = new Db();
			Connection conn = db.getConnection();
			PreparedStatement statement;
			statement = conn.prepareStatement(sql);
			statement.setString(1, student.getName());
			statement.setInt(2, student.getAge());
			statement.setString(3, student.getSection()); 
			statement.setString(4, student.getIdnumber());
			statement.setString(5, student.getGender());
			statement.setString(6, student.getEmail());
			statement.setString(7, student.getContactno());
			statement.setString(8, student.getAddress());
			statement.setLong(9, student.getStuid());
			int rowsUpdated = statement.executeUpdate();
			if (rowsUpdated > 0) {
				System.out.println("An existing Student was updated successfully!");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public boolean existsById(Long stuid) {
		String sql = "SELECT * FROM student where stuid = " + stuid + "";
		Db db = new Db();
		Connection conn = db.getConnection();
		Statement statement;
		try {
			statement = conn.createStatement();
			ResultSet result = statement.executeQuery(sql);
			while (result.next()) {
				if (result.getString(1).isEmpty()) {
					return false;
				} else {
					return true;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	public void deleteById(Long empid) {
		try {
			Db db = new Db();
			Connection conn = db.getConnection();
			String sql = "DELETE FROM student WHERE stuid=?";

			PreparedStatement statement = conn.prepareStatement(sql);
			statement.setLong(1, empid);
			int rowsDeleted = statement.executeUpdate();
			if (rowsDeleted > 0) {
				System.out.println("Student Deleted successfully!");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String count() {
		String sql = "SELECT count(*) as studentcount FROM student ";
		Db db = new Db();
		Connection conn = db.getConnection();
		Statement statement;
		try {
			statement = conn.createStatement();
			ResultSet result = statement.executeQuery(sql);
			while (result.next()) {
				if (result.getString("studentcount").isEmpty()) {
					return result.getString("studentcount");
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return "0";
	}

}
