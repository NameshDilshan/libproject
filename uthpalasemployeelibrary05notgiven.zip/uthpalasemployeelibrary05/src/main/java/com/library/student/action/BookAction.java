package com.library.student.action;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.library.student.dao.BookDao;
import com.library.student.domain.Book;

@Controller
public class BookAction {

    @Autowired
    private BookDao bookdao;

    @PostMapping("/saveBookDomain")
    public String saveBook(@ModelAttribute("book") Book book, Model model) {
        if (bookdao.existsById(book.getBookno())) {
        	bookdao.update(book);
        } else {
        	bookdao.save(book);
        }
        return "redirect:/book";
    }

    @DeleteMapping("/books/{id}")
    @ResponseBody
    public Boolean deleteBookDomain(@PathVariable(value = "id") Long id, Model model) {
        if (bookdao.existsById(id)) {
        	bookdao.deleteById(id);
            return Boolean.TRUE;
        }
        return Boolean.FALSE;
    }

}
