package com.library.student.dto;

import lombok.Data;

@Data
public class ObtainDto {

    private Long id;
    private String obtaindate;
    private String duedate;
    private String returneddate;
    private String fine;

    private String stuid;
    private String stuname;
    private String bookid;
    private String bookname;


}
