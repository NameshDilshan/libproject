package com.library.student.domain;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Entity
@Data
public class Book {

    @Id
    private Long bookno;

    private String title;
    private String authname;
    private Integer year;
    private String publisher;
    private String type;
    private String price;
 
}
