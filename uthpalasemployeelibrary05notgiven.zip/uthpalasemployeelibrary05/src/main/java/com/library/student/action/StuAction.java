package com.library.student.action;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.library.student.dao.StuDao;
import com.library.student.domain.Student;

@Controller
public class StuAction {

    @Autowired
    private StuDao stuDao;

    @PostMapping("/saveStu")
    public String saveStuDomain(@ModelAttribute("student") Student stu, Model model) {
        if (stuDao.existsById(stu.getStuid())) {
        	stuDao.update(stu);
        } else {
        	stuDao.save(stu);
        }
        return "redirect:/student";
    }

    @DeleteMapping("/employees/{id}")
    @ResponseBody
    public Boolean deleteStudentDomain(@PathVariable(value = "id") Long id, Model model) {
        if (stuDao.existsById(id)) {
        	stuDao.deleteById(id);
            return Boolean.TRUE;
        }
        return Boolean.FALSE;
    }

}
