package com.library.member.Repository;

import com.library.member.Entity.Member;
import com.library.member.datasource.Database;
import org.springframework.stereotype.Component;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@Component
public class MemberRepository {

    public List<Member> findAll() {
        String sql = "SELECT * FROM member";
        Database database = new Database();
        Connection conn = database.getConnection();
        Statement statement;
        List<Member> memberList = new ArrayList<Member>();
        try {
            statement = conn.createStatement();
            ResultSet result = statement.executeQuery(sql);
            while (result.next()) {
                System.out.println(result);
                Member member = new Member();
                member.setRegno(result.getLong("regno"));
                member.setNicname(result.getString("nicname"));
                member.setAge(result.getInt("age"));
                member.setFullname(result.getString("fullname"));
                member.setGender(result.getString("gender"));
                member.setAddress(result.getString("address"));
                member.setEmail(result.getString("email"));
                member.setMobile(result.getString("mobile"));
                memberList.add(member);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return memberList;
    }

    public void save(Member member) {
        try {
            Database database = new Database();
            Connection conn = database.getConnection();
            String sql = "INSERT INTO member  (`regno`,`address`,`age`,`email`,`fullname`,`gender`,`mobile`,`nicname` ) VALUES (?, ?, ?, ?, ?, ?, ? ,?)";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setLong(1, member.getRegno());
            statement.setString(2, member.getAddress());
            statement.setInt(3, member.getAge());
            statement.setString(4, member.getEmail());
            statement.setString(5, member.getFullname());
            statement.setString(6, member.getGender());
            statement.setString(7, member.getMobile());
            statement.setString(8, member.getNicname());
            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("A new Member inserted successfully!");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void update(Member member) {
        try {
            String sql = "UPDATE member SET address=?, age=?, email=? , fullname=?, gender=?, mobile=?, nicname=? WHERE regno=?";
            Database database = new Database();
            Connection conn = database.getConnection();
            PreparedStatement statement;
            statement = conn.prepareStatement(sql);
            statement.setString(1, member.getAddress());
            statement.setInt(2, member.getAge());
            statement.setString(3, member.getEmail());
            statement.setString(4, member.getFullname());
            statement.setString(5, member.getGender());
            statement.setString(6, member.getMobile());
            statement.setString(7, member.getNicname());
            statement.setLong(8, member.getRegno());
            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("An existing member was updated successfully!");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean existsById(Long regno) {
        String sql = "SELECT * FROM member where regno = " + regno + "";
        Database database = new Database();
        Connection conn = database.getConnection();
        Statement statement;
        try {
            statement = conn.createStatement();
            ResultSet result = statement.executeQuery(sql);
            while (result.next()) {
                if (result.getString(1).isEmpty()) {
                    return false;
                } else {
                    return true;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public void deleteById(Long regno) {
        try {
            Database database = new Database();
            Connection conn = database.getConnection();
            String sql = "DELETE FROM member WHERE regno=?";

            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setLong(1, regno);
            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Member Deleted successfully!");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String count() {
        String sql = "SELECT count(*) FROM member ";
        Database database = new Database();
        Connection conn = database.getConnection();
        Statement statement;
        try {
            statement = conn.createStatement();
            ResultSet result = statement.executeQuery(sql);
            while (result.next()) {
                if (result.getString("count(*)").isEmpty()) {
                    return result.getString("count(*)");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "0";
    }

}
