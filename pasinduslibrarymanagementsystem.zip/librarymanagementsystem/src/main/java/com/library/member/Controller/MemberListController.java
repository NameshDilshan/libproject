package com.library.member.Controller;

import com.library.member.Entity.Member;
import com.library.member.Repository.MemberRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class MemberListController {

    @Autowired
    private MemberRepository memberRepository;

    @PostMapping("/saveMember")
    public String saveGuest(@ModelAttribute("member") Member member, Model model) {
        if (memberRepository.existsById(member.getRegno())) {
            memberRepository.update(member);
        } else {
            memberRepository.save(member);
        }
        return "redirect:/memberManagementDashboard";
    }

    @DeleteMapping("/members/{id}")
    @ResponseBody
    public Boolean deleteMember(@PathVariable Long id, Model model) {
        if (memberRepository.existsById(id)) {
            memberRepository.deleteById(id);
            return Boolean.TRUE;
        }
        return Boolean.FALSE;
    }

}
