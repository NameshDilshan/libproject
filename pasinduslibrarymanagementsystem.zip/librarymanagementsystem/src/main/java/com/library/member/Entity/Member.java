package com.library.member.Entity;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
@Data
public class Member {

    @Id
    private Long regno;
    private String nicname;
    private Integer age;
    private String fullname;
    private String gender;
    private String address;
    private String email;
    private String mobile;

}
