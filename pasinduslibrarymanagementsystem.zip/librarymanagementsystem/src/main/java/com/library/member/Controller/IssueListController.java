package com.library.member.Controller;

import com.library.member.Entity.Issue;
import com.library.member.Repository.IssueRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class IssueListController {

    @Autowired
    private IssueRepository issueRepository;

    @PostMapping("/saveIssue")
    public String saveIssue(@ModelAttribute("issue") Issue issue, Model model) {
        if (issueRepository.existsById(issue.getId())) {
            issueRepository.update(issue);
        } else {
            issueRepository.save(issue);
        }
        return "redirect:/issueManagementDashboard";
    }

    @DeleteMapping("/issues/{id}")
    @ResponseBody
    public Boolean deleteIssue(@PathVariable Long id, Model model) {
        if (issueRepository.existsById(id)) {
            issueRepository.deleteById(id);
            System.out.println(" Issue Deleted Successfully  ID : " + id);
            return Boolean.TRUE;
        }
        return Boolean.FALSE;
    }

}
