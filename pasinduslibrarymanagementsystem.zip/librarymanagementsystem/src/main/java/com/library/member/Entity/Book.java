package com.library.member.Entity;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
@Data
public class Book {

    @Id
    private Long id;

    private String title;
    private String description;
    private Integer year;
    private String edition;
    private String category;
    private String price;

}
