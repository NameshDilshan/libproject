package com.library.member.Repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.library.member.Entity.Member;
import com.library.member.datasource.Database;

//public interface MemberRepository extends JpaRepository<Member, Long>{
@Component
public class MemberRepository{

	public List<Member> findAll() {
		String sql = "SELECT * FROM member";
		Database database = new Database();
		Connection conn = database.getConnection();
		Statement statement;
		List<Member> memberList = new ArrayList<Member>();
		try {
			statement = conn.createStatement();
			ResultSet result = statement.executeQuery(sql);
			while (result.next()) {
				System.out.println(result);
				Member member= new Member();
				member.setEmpcode(result.getLong("empcode"));
				member.setName(result.getString("name"));
				member.setAge(result.getInt("age"));
				member.setDepartment(result.getString("department"));
				member.setDesignation(result.getString("designation"));
				member.setGender(result.getString("gender"));
				member.setEmail(result.getString("email"));
				member.setMobile(result.getString("mobile"));  
//				member.setIdnumber(result.getString("idnumber"));
				memberList.add(member);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return memberList;
	}

	public void save(Member member) {
		try {
			Database database = new Database();
			Connection conn = database.getConnection();
			String sql = "INSERT INTO member  (`empcode`,`name`,`age`,`department`,`designation`,`gender`,`email`,`mobile` ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
			PreparedStatement statement = conn.prepareStatement(sql);
			statement.setLong(1, member.getEmpcode());
			statement.setString(2, member.getName());
			statement.setInt(3, member.getAge());
			statement.setString(4, member.getDepartment());
			statement.setString(5, member.getDesignation());
			statement.setString(6, member.getGender()); 
			statement.setString(7, member.getEmail());
			statement.setString(8, member.getMobile());
//			statement.setString(9, member.getIdnumber());
			int rowsInserted = statement.executeUpdate();
			if (rowsInserted > 0) {
			    System.out.println("A new Member inserted successfully!");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void update(Member member) { 
		try {
			String sql = "UPDATE member SET name=?, age=?, department=? , designation=?, gender=?, email=?, mobile=? WHERE empcode=?";
			Database database = new Database();
			Connection conn = database.getConnection();
			PreparedStatement statement;
			statement = conn.prepareStatement(sql);
			statement.setString(1, member.getName());
			statement.setInt(2, member.getAge());
			statement.setString(3, member.getDepartment());
			statement.setString(4, member.getDesignation());
			statement.setString(5, member.getGender());
			statement.setString(6, member.getEmail());  
			statement.setString(7, member.getMobile());  
//			statement.setString(8, member.getIdnumber());  
			statement.setLong(8, member.getEmpcode()); 
			int rowsUpdated = statement.executeUpdate();
			if (rowsUpdated > 0) {
			    System.out.println("An existing member was updated successfully!");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}   
	}
	
	public boolean existsById(Long empcode) {
		String sql = "SELECT * FROM member where empcode = "+empcode+"";
		Database database = new Database();
		Connection conn = database.getConnection();
		Statement statement; 
		try {
			statement = conn.createStatement();
			ResultSet result = statement.executeQuery(sql);
			while (result.next()) {
				if(result.getString(1).isEmpty()) {
					return false;
				}else {
					return true;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	} 
	
	public void deleteById(Long empcode) {
		try { 
			Database database = new Database();
			Connection conn = database.getConnection();
			String sql = "DELETE FROM member WHERE empcode=?";
			 
			PreparedStatement statement = conn.prepareStatement(sql);
			statement.setLong(1, empcode); 
			int rowsDeleted = statement.executeUpdate();
			if (rowsDeleted > 0) {
			    System.out.println("Member Deleted successfully!");
			} 
		} catch (Exception e) {
			e.printStackTrace();
		}   
	}
	
	public String count() {
		String sql = "SELECT count(*) FROM member ";
		Database database = new Database();
		Connection conn = database.getConnection();
		Statement statement;
		try {
			statement = conn.createStatement();
			ResultSet result = statement.executeQuery(sql);
			while (result.next()) {
				if(result.getString("count(*)").isEmpty()) {
					return result.getString("count(*)");
				} 
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return "0";
	}

}
