package com.library.member.Entity;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;
 
@Entity
@Data
public class Member {

	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long empcode;
	private String name;
	private Integer age;
	private String department;
	private String designation;
	private String gender;
	private String email;
	private String mobile; 
//	private String address;
//	private String idnumber;
	
//	@JsonIgnore
//	@OneToMany(mappedBy = "member", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
//	private List<Issue> issueList;
}
