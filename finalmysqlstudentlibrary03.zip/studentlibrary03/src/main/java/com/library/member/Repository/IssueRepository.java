/**
 * 
 */
package com.library.member.Repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

import com.library.member.Entity.Issue;
import com.library.member.datasource.Database;
import com.library.member.dto.IssueDto;

//public interface IssueRepository extends JpaRepository<Issue, Long>{
@Component
public class IssueRepository {

//		@Query(value = "SELECT * FROM issue WHERE issued_date BETWEEN (:start) AND (:end) AND book_id LIKE (:bookId) AND member_regno LIKE (:memberid) " , nativeQuery = true)
//		List<Issue> findIssuesByBookIdAndMemberIdAndIssuedDateRange(String start, String end, String bookId, String memberid);

	public List<IssueDto> findAll() {
		String sql = " SELECT i.*, member.name AS member_name, book.name AS book_name FROM issue AS i "
				+ " INNER JOIN member ON i.member_number = member.empcode INNER JOIN book ON i.book_id = book.id; ";
		Database database = new Database();
		Connection conn = database.getConnection();
		Statement statement;
		List<IssueDto> issueList = new ArrayList<IssueDto>();
		try {
			statement = conn.createStatement();
			ResultSet result = statement.executeQuery(sql);
			while (result.next()) {
				IssueDto issue = new IssueDto();
				issue.setId(result.getLong("id"));
				issue.setIssuedate(result.getString("issued_date"));
				issue.setDuedate(result.getString("due_date"));
				issue.setReturndate(result.getString("returned_date"));
				issue.setFine(result.getString("fine"));
				issue.setMemberno(result.getString("member_number"));
				issue.setMembername(result.getString("member_name"));
				issue.setBookid(result.getString("book_id"));
				issue.setBookname(result.getString("book_name"));
				issueList.add(issue);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return issueList;
	}

	public void save(Issue issue) {
		try {
			Database database = new Database();
			Connection conn = database.getConnection();
			String sql = "INSERT INTO issue  ( `issued_date`, `due_date`, `returned_date`, `fine`, `member_number`, `book_id`) VALUES ( ?, ?, ?, ?, ?, ?)";
			PreparedStatement statement = conn.prepareStatement(sql);
			statement.setString(1, issue.getIssued_date());
			statement.setString(2, issue.getDue_date());
			statement.setString(3, issue.getReturned_date());
			statement.setString(4, issue.getFine());
			statement.setString(5, issue.getMember_number());
			statement.setString(6, issue.getBook_id());
			int rowsInserted = statement.executeUpdate();
			if (rowsInserted > 0) {
				System.out.println("A new Issue inserted successfully!");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void update(Issue issue) {
		try {
			String sql = "UPDATE issue SET issued_date=?, due_date=?, returned_date=? , fine=?, member_number=?, book_id=? WHERE id=?";
			Database database = new Database();
			Connection conn = database.getConnection();
			PreparedStatement statement;
			statement = conn.prepareStatement(sql);
			statement.setString(1, issue.getIssued_date());
			statement.setString(2, issue.getDue_date());
			statement.setString(3, issue.getReturned_date());
			statement.setString(4, issue.getFine());
			statement.setString(5, issue.getMember_number());
			statement.setString(6, issue.getBook_id());
			statement.setLong(7, issue.getId());
			int rowsUpdated = statement.executeUpdate();
			if (rowsUpdated > 0) {
				System.out.println("An existing issue was updated successfully!");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public boolean existsById(Long id) {
		String sql = "SELECT * FROM issue where id = " + id + "";
		Database database = new Database();
		Connection conn = database.getConnection();
		Statement statement;
		try {
			statement = conn.createStatement();
			ResultSet result = statement.executeQuery(sql);
			while (result.next()) {
				if (result.getString(1).isEmpty()) {
					return false;
				} else {
					return true;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	public void deleteById(Long id) {
		try {
			Database database = new Database();
			Connection conn = database.getConnection();
			String sql = "DELETE FROM issue WHERE id=?";

			PreparedStatement statement = conn.prepareStatement(sql);
			statement.setLong(1, id);
			int rowsDeleted = statement.executeUpdate();
			if (rowsDeleted > 0) {
				System.out.println("Issue Deleted successfully!");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public List<IssueDto> getReportDetailsByDateAndBookMemberIds(String start, String end, String bookId, String memberid) {
		String sql = " SELECT i.*, member.name AS member_name, book.name AS book_name FROM issue AS i "
				+ "   INNER JOIN member ON i.member_number = member.empcode INNER JOIN book ON i.book_id = book.id " 
				+ " WHERE issued_date BETWEEN '" + start + "' AND '" + end
				+ "' AND i.book_id LIKE '" + bookId + "' AND member_number LIKE '" + memberid + "' ; ";
		Database database = new Database();
		Connection conn = database.getConnection();
		Statement statement;
		List<IssueDto> issueList = new ArrayList<IssueDto>();
		try {
			statement = conn.createStatement();
			ResultSet result = statement.executeQuery(sql);
			while (result.next()) {
				IssueDto issue = new IssueDto();
				issue.setId(result.getLong("id"));
				issue.setIssuedate(result.getString("issued_date"));
				issue.setDuedate(result.getString("due_date"));
				issue.setReturndate(result.getString("returned_date"));
				issue.setFine(result.getString("fine"));
				issue.setMemberno(result.getString("member_number"));
				issue.setMembername(result.getString("member_name"));
				issue.setBookid(result.getString("book_id"));
				issue.setBookname(result.getString("book_name"));
				issueList.add(issue);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return issueList;
	}

//	public List<IssueDto> getReportDetailsByDateAndBookMemberIds(String start, String end, String bookid, String memberid) {
//		String sql = " SELECT i.*, member.nicname AS membername, book.title AS bookname FROM issue AS i "
//				+ "   INNER JOIN member ON i.memberno = member.regno " + "	INNER JOIN book ON i.bookid = book.id "
//				+ " WHERE issuedate BETWEEN '" + start + "' AND '" + end + "' AND i.bookid LIKE '" + bookid
//				+ "' AND memberno LIKE '" + memberid + "' ; ";
//		Database database = new Database();
//		Connection conn = database.getConnection();
//		Statement statement;
//		List<IssueDto> issueList = new ArrayList<IssueDto>();
//		try {
//			statement = conn.createStatement();
//			ResultSet result = statement.executeQuery(sql);
//			while (result.next()) {
//				IssueDto issue = new IssueDto();
//				issue.setId(result.getLong("id"));
//				issue.setIssuedate(result.getString("issuedate"));
//				issue.setDuedate(result.getString("duedate"));
//				issue.setReturndate(result.getString("returndate"));
//				issue.setFine(result.getString("fine"));
//				issue.setMemberno(result.getString("memberno"));
//				issue.setMembername(result.getString("membername"));
//				issue.setBookid(result.getString("bookid"));
//				issue.setBookname(result.getString("bookname"));
//				issueList.add(issue);
//			}
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
//		return issueList;
//	}

}
