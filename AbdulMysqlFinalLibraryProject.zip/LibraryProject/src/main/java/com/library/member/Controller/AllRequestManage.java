package com.library.member.Controller;

import com.library.member.Repository.MembersManageDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.library.member.Entity.Book;
import com.library.member.Entity.Issue;
import com.library.member.Entity.Member;
import com.library.member.Repository.BooksManageDao;
import com.library.member.Repository.IssuesManageDao;

@Controller
public class AllRequestManage {

	@Autowired
	private BooksManageDao booksManageDao;
	
	@Autowired
	private MembersManageDao membersManageDao;
	
	@Autowired
	private IssuesManageDao issuesManageDao;
	
	@GetMapping("/")
	public String mainManu(Model model) { 
		model.addAttribute("memberCount", membersManageDao.count());
		model.addAttribute("fineCount", booksManageDao.count());
		return "index.jsp";
	}
	
	@GetMapping("/manageBooks")
	public String manageBooks(Model model) {
		model.addAttribute("book", new Book());
		model.addAttribute("bookList", booksManageDao.findAll());
		return "booksManage.jsp";
	}
	
	@GetMapping("/manageMembers")
	public String manageMembers(Model model) {
		model.addAttribute("member", new Member());
		model.addAttribute("memberList", membersManageDao.findAll());
		return "membersManagement.jsp";
	}
	
	@GetMapping("/manageIssues")
	public String manageIssues(Model model) {
		model.addAttribute("issue", new Issue());
		model.addAttribute("issueList", issuesManageDao.findAll());
		model.addAttribute("books", booksManageDao.findAll());
		model.addAttribute("members", membersManageDao.findAll());
		return "issuesManage.jsp";
	} 
	
	@GetMapping("/bookReport")
	public String getBookReport(Model model) { 
		model.addAttribute("books", booksManageDao.findAll());
		model.addAttribute("members", membersManageDao.findAll());
		return "reports/bookReport.jsp";
	}
	
	@GetMapping("/feeReport")
	public String getFeeReport(Model model) { 
		model.addAttribute("books", booksManageDao.findAll());
		model.addAttribute("members", membersManageDao.findAll());
		return "reports/feeReport.jsp";
	}
	
}
