package com.library.member.dto;

import lombok.Data;

@Data
public class IssueDto { 
	private Long id;
	private String issuedate;
	private String duedate;
	private String returndate;
	private String fine; 
	private String memberno;
	private String membername;
	private String bookid;
	private String bookname; 
}
