package com.library.member.Repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.library.member.Entity.Member;
import com.library.member.datasource.DbConnector;

@Component
public class MembersManageDao{

	public List<Member> findAll() {
		String sql = "SELECT * FROM member";
		DbConnector dbConnector = new DbConnector();
		Connection connector = dbConnector.getConnection();
		Statement statement;
		List<Member> memberList = new ArrayList<Member>();
		try {
			statement = connector.createStatement();
			ResultSet result = statement.executeQuery(sql);
			while (result.next()) {
				System.out.println(result);
				Member member= new Member();
				member.setStudentcode(result.getLong("studentcode"));
				member.setName(result.getString("name"));
				member.setAge(result.getInt("age"));
				member.setStream(result.getString("stream"));
				member.setClassnumber(result.getString("classnumber"));
				member.setGender(result.getString("gender"));
				member.setEmail(result.getString("email"));
				member.setMobile(result.getString("mobile"));   
				memberList.add(member);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return memberList;
	}

	public void save(Member member) {
		try {
			DbConnector dbConnector = new DbConnector();
			Connection connector = dbConnector.getConnection();
			String sql = "INSERT INTO member  (`studentcode`,`name`,`age`,`stream`,`classnumber`,`gender`,`email`,`mobile` ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
			PreparedStatement statement = connector.prepareStatement(sql);
			statement.setLong(1, member.getStudentcode());
			statement.setString(2, member.getName());
			statement.setInt(3, member.getAge());
			statement.setString(4, member.getStream());
			statement.setString(5, member.getClassnumber());
			statement.setString(6, member.getGender()); 
			statement.setString(7, member.getEmail());
			statement.setString(8, member.getMobile()); 
			int rowsInserted = statement.executeUpdate();
			if (rowsInserted > 0) {
			    System.out.println("A new Member inserted successfully!");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void update(Member member) { 
		String sql = "UPDATE member SET name=?, age=?, stream=? , classnumber=?, gender=?, email=?, mobile=? WHERE studentcode=?";
		DbConnector dbConnector = new DbConnector();
		Connection connector = dbConnector.getConnection();
		PreparedStatement statement;
		try { 
			statement = connector.prepareStatement(sql);
			statement.setString(1, member.getName());
			statement.setInt(2, member.getAge());
			statement.setString(3, member.getStream());
			statement.setString(4, member.getClassnumber());
			statement.setString(5, member.getGender());
			statement.setString(6, member.getEmail());  
			statement.setString(7, member.getMobile());    
			statement.setLong(8, member.getStudentcode());
			int rowsUpdated = statement.executeUpdate();
			if (rowsUpdated > 0) {
			    System.out.println("An existing member was updated successfully!");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}   
	}
	
	public boolean existsById(Long studentcode) {
		String sql = "SELECT * FROM member where studentcode = "+studentcode+"";
		DbConnector dbConnector = new DbConnector();
		Connection connector = dbConnector.getConnection();
		Statement statement; 
		try {
			statement = connector.createStatement();
			ResultSet result = statement.executeQuery(sql);
			while (result.next()) {
				if(result.getString(1).isEmpty()) {
					return false;
				}else {
					return true;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	} 
	
	public void deleteById(Long studentcode) {
		try { 
			DbConnector dbConnector = new DbConnector();
			Connection connector = dbConnector.getConnection();
			String sql = "DELETE FROM member WHERE studentcode=?";
			 
			PreparedStatement statement = connector.prepareStatement(sql);
			statement.setLong(1, studentcode);
			int rowsDeleted = statement.executeUpdate();
			if (rowsDeleted > 0) {
			    System.out.println("Member Deleted successfully!");
			} 
		} catch (Exception e) {
			e.printStackTrace();
		}   
	}
	
	public String count() {
		String sql = "SELECT count(*) FROM member ";
		DbConnector dbConnector = new DbConnector();
		Connection connector = dbConnector.getConnection();
		Statement statement;
		try {
			statement = connector.createStatement();
			ResultSet result = statement.executeQuery(sql);
			while (result.next()) {
				if(result.getString("count(*)").isEmpty()) {
					return result.getString("count(*)");
				} 
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return "0";
	}

}
