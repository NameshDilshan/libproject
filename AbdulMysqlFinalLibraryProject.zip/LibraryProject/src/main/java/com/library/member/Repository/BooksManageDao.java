package com.library.member.Repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.library.member.Entity.Book;
import com.library.member.datasource.DbConnector;

@Component
public class BooksManageDao {

	public List<Book> findAll() {
		String sql = "SELECT * FROM book";
		DbConnector dbConnector = new DbConnector();
		Connection connection = dbConnector.getConnection();
		Statement statement;
		List<Book> bookList = new ArrayList<Book>();
		try {
			statement = connection.createStatement();
			ResultSet result = statement.executeQuery(sql);
			while (result.next()) { 
				Book book= new Book();
				book.setId(result.getLong("id"));
				book.setName(result.getString("name"));
				book.setAuthor(result.getString("author"));
				book.setYear(result.getInt("year"));
				book.setEdition(result.getString("edition"));
				book.setGenre(result.getString("genre"));
				book.setPrice(result.getString("price"));
				bookList.add(book);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return bookList;
	}

	public void save(Book book) {
		DbConnector dbConnector = new DbConnector();
		Connection conection = dbConnector.getConnection();
		String sql = "INSERT INTO book  (`id`, `name`, `author`, `year`, `edition`, `genre`, `price` ) VALUES (?, ?, ?, ?, ?, ?, ?)";
		try { 
			PreparedStatement statement = conection.prepareStatement(sql);
			statement.setLong(1, book.getId());
			statement.setString(2, book.getName());
			statement.setString(3, book.getAuthor());
			statement.setInt(4, book.getYear());
			statement.setString(5, book.getEdition());
			statement.setString(6, book.getGenre());
			statement.setString(7, book.getPrice());
			int rowsInserted = statement.executeUpdate();
			if (rowsInserted > 0) {
			    System.out.println("A new Book inserted successfully!");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void update(Book book) { 
		String sql = "UPDATE book SET name=?, author=?, year=? , edition=?, genre=?, price=? WHERE id=?";
		DbConnector dbConnector = new DbConnector();
		Connection conn = dbConnector.getConnection();
		PreparedStatement statement;
		try { 
			statement = conn.prepareStatement(sql);
			statement.setString(1, book.getName());
			statement.setString(2, book.getAuthor());
			statement.setInt(3, book.getYear());
			statement.setString(4, book.getEdition());
			statement.setString(5, book.getGenre());
			statement.setString(6, book.getPrice());  
			statement.setLong(7, book.getId());  
			int rowsUpdated = statement.executeUpdate();
			if (rowsUpdated > 0) {
			    System.out.println("An existing book was updated successfully!");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}   
	}
	
	public boolean existsById(Long id) {
		String sql = "SELECT * FROM book where id = "+id+"";
		DbConnector dbConnector = new DbConnector();
		Connection conn = dbConnector.getConnection();
		Statement statement; 
		try {
			statement = conn.createStatement();
			ResultSet result = statement.executeQuery(sql);
			while (result.next()) {
				if(result.getString(1).isEmpty()) {
					return false;
				}else {
					return true;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	} 
	
	public void deleteById(Long id) {
		DbConnector dbConnector = new DbConnector();
		Connection conn = dbConnector.getConnection();
		String sql = "DELETE FROM book WHERE id=?";
		try {  
			PreparedStatement statement = conn.prepareStatement(sql);
			statement.setLong(1, id); 
			int rowsDeleted = statement.executeUpdate();
			if (rowsDeleted > 0) {
			    System.out.println("Book Deleted successfully!");
			} 
		} catch (Exception e) {
			e.printStackTrace();
		}   
	}

	public String count() {
		String sql = "SELECT count(*) FROM book ";
		DbConnector dbConnector = new DbConnector();
		Connection conn = dbConnector.getConnection();
		Statement statement;
		try {
			statement = conn.createStatement();
			ResultSet result = statement.executeQuery(sql);
			while (result.next()) {
				if(result.getString("count(*)").isEmpty()) {
					return result.getString("count(*)");
				} 
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return "0";
	}
} 
