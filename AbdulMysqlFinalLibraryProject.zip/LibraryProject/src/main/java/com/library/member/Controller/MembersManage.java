/**
 * 
 */
package com.library.member.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.library.member.Entity.Member;
import com.library.member.Repository.MembersManageDao;

@Controller
public class MembersManage {

	@Autowired
	private MembersManageDao membersManageDao;
	
	@PostMapping("/saveMemberObject")
	public String save(@ModelAttribute("member") Member member, Model model) {
		if(membersManageDao.existsById(member.getStudentcode())) {
			membersManageDao.update(member);
		}else {
			membersManageDao.save(member);
		}
		return "redirect:/manageMembers";
	}
	
	@DeleteMapping("/members/{id}")
	@ResponseBody
	public Boolean delete(@PathVariable Long id , Model model) {  
		if(membersManageDao.existsById(id)) {
			membersManageDao.deleteById(id);  
			return Boolean.TRUE;
		} 
		return Boolean.FALSE;
	} 
	
}
