package com.library.member.Entity;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;
 
@Entity
@Data
public class Member {

	@Id 
	private Long studentcode;
	private String name;
	private Integer age;
	private String stream;
	private String classnumber;
	private String gender;
	private String email;
	private String mobile; 
}
