package com.library.member.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.library.member.Entity.Issue;
import com.library.member.Repository.IssuesManageDao;

@Controller
public class IssuesManage {

	@Autowired
	private IssuesManageDao issuesManageDao;
	
	@PostMapping("/saveIssueObject")
	public String save(@ModelAttribute("issue") Issue issue, Model model) { 
		if(issuesManageDao.existsById(issue.getId())) {
			issuesManageDao.update(issue);
		}else {
			issuesManageDao.save(issue);
		}
		return "redirect:/manageIssues"; 
	}
	
	@DeleteMapping("/issues/{id}")
	@ResponseBody
	public Boolean delete(@PathVariable Long id , Model model) {  
		if(issuesManageDao.existsById(id)) {
			issuesManageDao.deleteById(id); 
			System.out.println(" Issue Deleted Successfully  ID : "+ id);
			return Boolean.TRUE;
		} 
		return Boolean.FALSE;
	} 
	
}
