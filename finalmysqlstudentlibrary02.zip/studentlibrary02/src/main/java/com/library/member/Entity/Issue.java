package com.library.member.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Data;

@Entity
@Data
public class Issue {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String issuedate;
	private String duedate;
	private String returndate;
	private String fine;
	
	private String memberno;
	private String bookid;
	
//	@ManyToOne
//	private Book book;
	
//	@ManyToOne
//	private Member member;
}
