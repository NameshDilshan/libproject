package com.library.member.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.library.member.Entity.Issue;
import com.library.member.Repository.IssueRepository;
import com.library.member.dto.IssueDto;

@RestController	
public class ReportController {

	@Autowired
	private IssueRepository issueRepository;
	
	@PostMapping("/getReportData")
	public List<IssueDto> getFindIssuesByBookIdAndMemberIdAndIssuedDateRange(
			@RequestParam(name = "start", required = false, defaultValue = "1996-12-15") String start,
			@RequestParam(name = "end", required = false, defaultValue = "2996-12-15") String end,
			@RequestParam(name = "book", required = false, defaultValue = "%") String bookId,
			@RequestParam(name = "member", required = false, defaultValue = "%") String memberId
			){ 
		return issueRepository.getReportData(start, end, bookId, memberId);
	}
}
