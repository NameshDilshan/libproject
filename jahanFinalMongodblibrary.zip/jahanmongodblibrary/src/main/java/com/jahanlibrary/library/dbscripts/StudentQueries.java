package com.jahanlibrary.library.dbscripts;

import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Updates.combine;
import static com.mongodb.client.model.Updates.set;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;
import org.springframework.stereotype.Component;

import com.jahanlibrary.library.configuratons.Dbconnection;
import com.jahanlibrary.library.springentities.Student;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

@Component
public class StudentQueries{ 
	
	public List<Student> findAll() {
		List<Student> students = new ArrayList<Student>();
		Dbconnection conn = new Dbconnection();
		MongoDatabase mongoDb = conn.getCollection();
		try { 
			MongoCollection<Document> coll = mongoDb.getCollection("student"); 
			FindIterable<Document> docs = coll.find();
			for(Document doc : docs) {
				Student student= new Student();
				student.setRegnumber(doc.getLong("regnumber"));
				student.setName(doc.getString("name"));
				student.setAge(doc.getInteger("age"));
				student.setGender(doc.getString("gender"));
				student.setGrade(doc.getString("grade"));
				student.setStream(doc.getString("stream")); 
				student.setEmail(doc.getString("email"));
				student.setContactno(doc.getString("contactno"));  
				student.setAddress(doc.getString("address"));  
				students.add(student);
			} 
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return students; 
	}

	public void save(Student student) {
		Dbconnection conn = new Dbconnection();
		MongoDatabase mongoDb = conn.getCollection();
		try {
			MongoCollection<Document> coll = mongoDb.getCollection("student"); 
			Document doc = new Document()
	                .append("regnumber", student.getRegnumber())
	                .append("name", student.getName())
	                .append("age", student.getAge())
	                .append("gender", student.getGender())
	                .append("grade", student.getGrade())
	                .append("stream", student.getStream())
	                .append("email", student.getEmail())
	                .append("contactno", student.getContactno())
	                .append("address", student.getAddress());
			coll.insertOne(doc); 
		} catch (Exception e) {
			e.printStackTrace();
		}  
	}

	public void update(Student student) {  
		Dbconnection conn = new Dbconnection();
		MongoDatabase mongoDb = conn.getCollection();
		try {
			MongoCollection<Document> coll = mongoDb.getCollection("student"); 
			coll.updateOne(
                eq("regnumber", student.getRegnumber()),
                combine(
                		set("name", student.getName()), 
                		set("age", student.getAge()),
                		set("gender", student.getGender()), set("grade", student.getGrade()), 
                		set("stream", student.getStream()), set("email", student.getEmail()), 
                		set("contactno", student.getContactno()), set("address", student.getAddress())
                		)
                ); 
		} catch (Exception e) {
			e.printStackTrace();
		}   
	}
	
	public boolean existsById(Long regnumber) { 
		Dbconnection conn = new Dbconnection();
		MongoDatabase mongoDb = conn.getCollection();
		try { 
			MongoCollection<Document> coll = mongoDb.getCollection("student"); 
			FindIterable<Document> documents = coll.find(eq("regnumber", regnumber));
			for(Document doc : documents) { 
				if(doc.getLong("regnumber") != null) {
					return true;
				}else {
					return false;
				}
			} 
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	} 
	
	public void deleteById(Long regnumber) {
		Dbconnection conn = new Dbconnection();
		MongoDatabase mongoDb = conn.getCollection();
		try {  
			MongoCollection<Document> coll = mongoDb.getCollection("student"); 
			coll.deleteOne(eq("regnumber", regnumber)); 
		} catch (Exception e) {
			e.printStackTrace();
		}   
	}

	public Student findById(Long regnumber) {
		Student student= new Student();
		Dbconnection conn = new Dbconnection();
		MongoDatabase mongoDb = conn.getCollection();
		try { 
			MongoCollection<Document> coll = mongoDb.getCollection("student"); 
			Document doc = coll.find(eq("regnumber", regnumber)).first(); 
			student.setRegnumber(doc.getLong("intbooknumb"));
			student.setName(doc.getString("name"));
			student.setAge(doc.getInteger("age"));
			student.setGender(doc.getString("gender"));
			student.setGrade(doc.getString("grade"));
			student.setStream(doc.getString("stream"));
			student.setEmail(doc.getString("email"));
			student.setContactno(doc.getString("contactno")); 
			student.setAddress(doc.getString("address")); 
			return student;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}  
}
