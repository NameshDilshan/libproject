package com.jahanlibrary.library.springentities;

import lombok.Data;

@Data
public class Issueandreturn {
	private Long id;
	private String issuedate;
	private String duedate;
	private String returneddate;
	private String finepayment; 
	private String studentregnumber;
	private String studentname;
	private String intbooknumb; 
	private String bookname; 
}
