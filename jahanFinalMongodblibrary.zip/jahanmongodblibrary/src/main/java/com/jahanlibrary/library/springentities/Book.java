package com.jahanlibrary.library.springentities;

import lombok.Data;

@Data
public class Book {

	private Long intbooknumb; 
	private String name; 
	private String authorname;
	private Integer publishedyear;
	private String publisher;
	private String bookrowno;
	private String bookcount;
	private String pagecount; 
}
