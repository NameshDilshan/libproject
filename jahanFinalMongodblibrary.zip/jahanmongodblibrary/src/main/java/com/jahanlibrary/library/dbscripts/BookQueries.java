package com.jahanlibrary.library.dbscripts;

import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Updates.combine;
import static com.mongodb.client.model.Updates.set;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;
import org.springframework.stereotype.Component;

import com.jahanlibrary.library.configuratons.Dbconnection;
import com.jahanlibrary.library.springentities.Book;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

@Component
public class BookQueries {
 
	public List<Book> findAll() { 
		List<Book> books = new ArrayList<Book>();
		Dbconnection conn = new Dbconnection();
		MongoDatabase mongoDb = conn.getCollection();
		try { 
			MongoCollection<Document> coll = mongoDb.getCollection("book"); 
			FindIterable<Document> docs = coll.find();
			for(Document doc : docs) {
				Book book= new Book();
				book.setIntbooknumb(doc.getLong("intbooknumb"));
				book.setName(doc.getString("name"));
				book.setAuthorname(doc.getString("authorname"));
				book.setPublishedyear(doc.getInteger("publishedyear"));
				book.setPublisher(doc.getString("publisher"));
				book.setBookrowno(doc.getString("bookrowno"));
				book.setBookcount(doc.getString("bookcount"));
				book.setPagecount(doc.getString("pagecount")); 
				books.add(book);
			} 
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return books;
	}

	public void save(Book book) {
		Dbconnection conn = new Dbconnection();
		MongoDatabase mongoDb = conn.getCollection();
		try {
			MongoCollection<Document> coll = mongoDb.getCollection("book"); 
			Document doc = new Document()
	                .append("intbooknumb", book.getIntbooknumb())
	                .append("name", book.getName())
	                .append("authorname", book.getAuthorname())
	                .append("publishedyear", book.getPublishedyear())
	                .append("publisher", book.getPublisher())
	                .append("bookrowno", book.getBookrowno())
	                .append("bookcount", book.getBookcount())
	                .append("pagecount", book.getPagecount());
			coll.insertOne(doc); 
		} catch (Exception e) {
			e.printStackTrace();
		} 
	}

	public void update(Book book) {  
		Dbconnection conn = new Dbconnection();
		MongoDatabase mongoDb = conn.getCollection();
		try {
			MongoCollection<Document> coll = mongoDb.getCollection("book"); 
			coll.updateOne(
                eq("intbooknumb", book.getIntbooknumb()),
                combine(
                		set("name", book.getName()), 
                		set("authorname", book.getAuthorname()),
                		set("publishedyear", book.getPublishedyear()), set("publisher", book.getPublisher()), 
                		set("bookrowno", book.getBookrowno()), set("bookcount", book.getBookcount()), 
                		set("pagecount", book.getPagecount())
                		)
                ); 
		} catch (Exception e) {
			e.printStackTrace();
		}   
	}
	
	public boolean existsById(Long intbooknumb) { 
		Dbconnection conn = new Dbconnection();
		MongoDatabase mongoDb = conn.getCollection();
		try { 
			MongoCollection<Document> coll = mongoDb.getCollection("book"); 
			FindIterable<Document> documents = coll.find(eq("intbooknumb", intbooknumb));
			for(Document doc : documents) { 
				if(doc.getLong("intbooknumb") != null) {
					return true;
				}else {
					return false;
				}
			} 
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	} 
	
	public void deleteById(Long intbooknumb) {
		Dbconnection conn = new Dbconnection();
		MongoDatabase mongoDb = conn.getCollection();
		try {  
			MongoCollection<Document> coll = mongoDb.getCollection("book"); 
			coll.deleteOne(eq("intbooknumb", intbooknumb)); 
		} catch (Exception e) {
			e.printStackTrace();
		}   
	}

	public Book findById(Long intbooknumb) {
		Book book= new Book();
		Dbconnection conn = new Dbconnection();
		MongoDatabase mongoDb = conn.getCollection();
		try { 
			MongoCollection<Document> coll = mongoDb.getCollection("book"); 
			Document doc = coll.find(eq("intbooknumb", intbooknumb)).first(); 
			book.setIntbooknumb(doc.getLong("intbooknumb"));
			book.setName(doc.getString("name"));
			book.setAuthorname(doc.getString("authorname"));
			book.setPublishedyear(doc.getInteger("publishedyear"));
			book.setPublisher(doc.getString("publisher"));
			book.setBookrowno(doc.getString("bookrowno"));
			book.setBookcount(doc.getString("bookcount"));
			book.setPagecount(doc.getString("pagecount")); 
			return book;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}  
} 