package com.jahanlibrary.library.springentities;
import lombok.Data;

@Data
public class Student {
	private Long regnumber;
	private String name;
	private Integer age;
	private String gender;
	private String grade;
	private String stream; 
	private String email;
	private String contactno;  
	private String address;
	
}
