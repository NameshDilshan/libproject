package com.jahanlibrary.library.dbscripts;

import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Updates.combine;
import static com.mongodb.client.model.Updates.set;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;
import org.springframework.stereotype.Component;

import com.jahanlibrary.library.configuratons.Dbconnection;
import com.jahanlibrary.library.springentities.Issueandreturn;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;

@Component
public class IssueAndReturnQueries { 
	
	public List<Issueandreturn> findAll() {
		List<Issueandreturn> issueandreturns = new ArrayList<Issueandreturn>();
		Dbconnection conn = new Dbconnection();
		MongoDatabase mongoDb = conn.getCollection();
		try { 
			MongoCollection<Document> coll = mongoDb.getCollection("issueandreturn"); 
			FindIterable<Document> docs = coll.find();
			for(Document doc : docs) {
				Issueandreturn issueandreturn= new Issueandreturn();
				issueandreturn.setId(doc.getLong("id"));
				issueandreturn.setIssuedate(doc.getString("issuedate"));
				issueandreturn.setDuedate(doc.getString("duedate"));
				issueandreturn.setReturneddate(doc.getString("returneddate"));
				issueandreturn.setFinepayment(doc.getString("finepayment"));
				issueandreturn.setStudentregnumber(doc.getString("studentregnumber")); 
				issueandreturn.setStudentname(doc.getString("studentname"));
				issueandreturn.setIntbooknumb(doc.getString("intbooknumb"));  
				issueandreturn.setBookname(doc.getString("bookname"));  
				issueandreturns.add(issueandreturn);
			} 
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return issueandreturns; 
	}

	public void save(Issueandreturn issueandreturn) {
		Dbconnection conn = new Dbconnection();
		MongoDatabase mongoDb = conn.getCollection();
		try {
			MongoCollection<Document> coll = mongoDb.getCollection("issueandreturn"); 
			Document doc = new Document()
	                .append("id", issueandreturn.getId())
	                .append("issuedate", issueandreturn.getIssuedate())
	                .append("duedate", issueandreturn.getDuedate())
	                .append("returneddate", issueandreturn.getReturneddate())
	                .append("finepayment", issueandreturn.getFinepayment())
	                .append("studentregnumber", issueandreturn.getStudentregnumber())
	                .append("studentname", issueandreturn.getStudentname())
	                .append("intbooknumb", issueandreturn.getIntbooknumb())
	                .append("bookname", issueandreturn.getBookname());
			coll.insertOne(doc); 
		} catch (Exception e) {
			e.printStackTrace();
		}  
	}

	public void update(Issueandreturn issueandreturn) {  
		Dbconnection conn = new Dbconnection();
		MongoDatabase mongoDb = conn.getCollection();
		try {
			MongoCollection<Document> coll = mongoDb.getCollection("issueandreturn"); 
			coll.updateOne(
                eq("id", issueandreturn.getId()),
                combine(
                		set("issuedate", issueandreturn.getIssuedate()), 
                		set("duedate", issueandreturn.getDuedate()),
                		set("returneddate", issueandreturn.getReturneddate()), set("finepayment", issueandreturn.getFinepayment()), 
                		set("studentregnumber", issueandreturn.getStudentregnumber()), set("studentname", issueandreturn.getStudentname()), 
                		set("intbooknumb", issueandreturn.getIntbooknumb()), set("bookname", issueandreturn.getBookname())
                		)
                ); 
		} catch (Exception e) {
			e.printStackTrace();
		}   
	}
	
	public boolean existsById(Long id) { 
		Dbconnection conn = new Dbconnection();
		MongoDatabase mongoDb = conn.getCollection();
		try { 
			MongoCollection<Document> coll = mongoDb.getCollection("issueandreturn"); 
			FindIterable<Document> documents = coll.find(eq("id", id));
			for(Document doc : documents) { 
				if(doc.getLong("id") != null) {
					return true;
				}else {
					return false;
				}
			} 
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	} 
	
	public void deleteById(Long id) {
		Dbconnection conn = new Dbconnection();
		MongoDatabase mongoDb = conn.getCollection();
		try {  
			MongoCollection<Document> coll = mongoDb.getCollection("issueandreturn"); 
			coll.deleteOne(eq("id", id)); 
		} catch (Exception e) {
			e.printStackTrace();
		}   
	} 

	public List<Issueandreturn> getData(String startDate, String endDate, String intbooknumb, String studentregnumber) {
		Dbconnection conn = new Dbconnection();
		MongoDatabase mongoDb = conn.getCollection();
		List<Issueandreturn> issueandreturns = new ArrayList<Issueandreturn>();
		try { 
			MongoCollection<Document> coll = mongoDb.getCollection("issueandreturn"); 
			FindIterable<Document> docs = coll.find(Filters.and(
					eq("studentregnumber", studentregnumber), 
					eq("intbooknumb", intbooknumb), 
					Filters.gte("issuedate", startDate), 
					Filters.lte("issuedate", endDate)));  
			for(Document doc : docs) {
				Issueandreturn issueandreturn= new Issueandreturn();
				issueandreturn.setId(doc.getLong("id"));
				issueandreturn.setIssuedate(doc.getString("issuedate"));
				issueandreturn.setDuedate(doc.getString("duedate"));
				issueandreturn.setReturneddate(doc.getString("returneddate"));
				issueandreturn.setFinepayment(doc.getString("finepayment"));
				issueandreturn.setStudentregnumber(doc.getString("studentregnumber")); 
				issueandreturn.setStudentname(doc.getString("studentname"));
				issueandreturn.setIntbooknumb(doc.getString("intbooknumb"));  
				issueandreturn.setBookname(doc.getString("bookname"));  
				issueandreturns.add(issueandreturn);
			} 
		} catch (Exception e) {
			e.printStackTrace();
		}
		return issueandreturns;   
		
	}
}