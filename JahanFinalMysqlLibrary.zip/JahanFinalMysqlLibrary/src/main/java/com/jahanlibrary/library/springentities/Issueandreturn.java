package com.jahanlibrary.library.springentities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Data;

@Entity
@Data
public class Issueandreturn {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String issuedate;
	private String duedate;
	private String returneddate;
	private String finepayment; 
	private String studentregnumber;
	private String studentname;
	private String intbooknumb; 
	private String bookname; 
}
