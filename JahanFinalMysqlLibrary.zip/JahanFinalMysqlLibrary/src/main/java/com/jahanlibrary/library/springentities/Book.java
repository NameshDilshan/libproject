package com.jahanlibrary.library.springentities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Data;

@Entity
@Data
public class Book {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long intbooknumb;

	private String name; 
	private String authorname;
	private Integer publishedyear;
	private String publisher;
	private String bookrowno;
	private String bookcount;
	private String pagecount; 
}
