package com.jahanlibrary.library.springcontrollers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jahanlibrary.library.dbscripts.StudentQueries;
import com.jahanlibrary.library.springentities.Student;

@Controller
public class StudentController {

	@Autowired
	private StudentQueries stuQueries;
	
	@PostMapping("/saveStudentData")
	public String saveStudentData(@ModelAttribute("student") Student student, Model model) {  
		if(stuQueries.existsById(student.getRegnumber())) {
			stuQueries.update(student);
		}else {
			stuQueries.save(student); 	
		} 
		return "redirect:/student";
	}
	
	@DeleteMapping("/deletestudent/{regnumber}")
	@ResponseBody
	public Boolean deleteStudentDetails(@PathVariable Long regnumber , Model model) {  
		if(stuQueries.existsById(regnumber)) {
			stuQueries.deleteById(regnumber);  
			return Boolean.TRUE;
		} 
		return Boolean.FALSE;
	} 
	
}
