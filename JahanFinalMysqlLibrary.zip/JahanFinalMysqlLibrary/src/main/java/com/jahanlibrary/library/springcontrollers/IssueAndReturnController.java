package com.jahanlibrary.library.springcontrollers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jahanlibrary.library.dbscripts.BookQueries;
import com.jahanlibrary.library.dbscripts.IssueAndReturnQueries;
import com.jahanlibrary.library.dbscripts.StudentQueries;
import com.jahanlibrary.library.springentities.Issueandreturn;
 

@Controller
public class IssueAndReturnController {

	@Autowired
	private IssueAndReturnQueries issueAndReturnQueries;
	
	@Autowired
	private BookQueries bookQueries;
	
	@Autowired
	private StudentQueries studentQueries;
	
	@PostMapping("/saveIssueandreturn")
	public String saveIssueandreturn(@ModelAttribute("issueandreturn") Issueandreturn issueandreturn, Model model) { 
		System.out.println();
		issueandreturn.setBookname(bookQueries.findById(Long.valueOf(issueandreturn.getIntbooknumb())).getName());
		issueandreturn.setStudentname(studentQueries.findById(Long.valueOf(issueandreturn.getStudentregnumber())).getName());
		if(issueAndReturnQueries.existsById(issueandreturn.getId())) {
			issueAndReturnQueries.update(issueandreturn);
		}else {
			issueAndReturnQueries.save(issueandreturn);
		}
		if(issueandreturn.getReturneddate() != null) {
			return "redirect:/returnBook";
		}
		return "redirect:/issueBook"; 
	}
	
	@DeleteMapping("/issueandreturn/{id}")
	@ResponseBody
	public Boolean deleteIssueandreturnDetails(@PathVariable Long id , Model model) {  
		if(issueAndReturnQueries.existsById(id)) {
			issueAndReturnQueries.deleteById(id); 
			return Boolean.TRUE;
		} 
		return Boolean.FALSE;
	} 
	
}
