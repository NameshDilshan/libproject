package com.jahanlibrary.library.dbscripts;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.jahanlibrary.library.configuratons.Dbconnection;
import com.jahanlibrary.library.springentities.Student;

@Component
public class StudentQueries{

	@Autowired
	private Dbconnection dbConnection;
	
	public List<Student> findAll() {
		String sql = "SELECT * FROM student";
		Connection conn = null;
		try {
			conn = dbConnection.connect();
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		Statement statement;
		List<Student> studentList = new ArrayList<Student>();
		try {
			statement = conn.createStatement();
			ResultSet result = statement.executeQuery(sql);
			while (result.next()) { 
				Student student= new Student();
				student.setRegnumber(result.getLong("regnumber"));
				student.setName(result.getString("name"));
				student.setAge(result.getInt("age"));
				student.setGender(result.getString("gender"));
				student.setGrade(result.getString("grade"));
				student.setStream(result.getString("stream")); 
				student.setEmail(result.getString("email"));
				student.setContactno(result.getString("contactno"));  
				student.setAddress(result.getString("address"));  
				studentList.add(student);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return studentList;
	}

	public void save(Student student) {
		try {
			Connection conn = null;
			try {
				conn = dbConnection.connect();
			} catch (ClassNotFoundException e1) {
				e1.printStackTrace();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			String sql = " INSERT INTO student (`regnumber`,`name`,`age`,`gender`,`grade`,`stream`,`email`,`contactno`, `address` ) "
					+ " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
			PreparedStatement statement = conn.prepareStatement(sql);
			statement.setLong(1, student.getRegnumber());
			statement.setString(2, student.getName());
			statement.setInt(3, student.getAge());
			statement.setString(4, student.getGender());
			statement.setString(5, student.getGrade());
			statement.setString(6, student.getStream()); 
			statement.setString(7, student.getEmail());
			statement.setString(8, student.getContactno());
			statement.setString(9, student.getAddress());
			statement.executeUpdate(); 
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void update(Student student) { 
		try {
			String sql = "UPDATE student SET name=?, age=?, gender=? , grade=?, stream=?, email=?, contactno=?, address=? WHERE regnumber=?";
			Connection conn = null;
			try {
				conn = dbConnection.connect();
			} catch (ClassNotFoundException e1) {
				e1.printStackTrace();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			PreparedStatement statement;
			statement = conn.prepareStatement(sql);
			statement.setString(1, student.getName());
			statement.setInt(2, student.getAge());
			statement.setString(3, student.getGender());
			statement.setString(4, student.getGrade());
			statement.setString(5, student.getStream());
			statement.setString(6, student.getEmail());  
			statement.setString(7, student.getContactno());
			statement.setString(8, student.getAddress()); 
			statement.setLong(9, student.getRegnumber()); 
			statement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}   
	}
	
	public boolean existsById(Long regnumber) {
		Connection conn = null;
		try {
			conn = dbConnection.connect();
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		Statement statement; 
		try {
			statement = conn.createStatement();
			ResultSet result = statement.executeQuery("SELECT * FROM student where regnumber = "+regnumber+"");
			while (result.next()) {
				if(result.getString(1).isEmpty()) {
					return false;
				}else {
					return true;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	} 
	
	public void deleteById(Long regnumber) {
		try { 
			Connection conn = null;
			try {
				conn = dbConnection.connect();
			} catch (ClassNotFoundException e1) {
				e1.printStackTrace();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			PreparedStatement statement = conn.prepareStatement("DELETE FROM student WHERE regnumber=?");
			statement.setLong(1, regnumber); 
			statement.executeUpdate(); 
		} catch (Exception e) {
			e.printStackTrace();
		}   
	}
	
	public String count() {
		String sql = "SELECT count(*) as count FROM student ";
		Connection conn = null;
		try {
			conn = dbConnection.connect();
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		Statement statement;
		try {
			statement = conn.createStatement();
			ResultSet result = statement.executeQuery(sql);
			while (result.next()) {
				if(result.getString("count").isEmpty()) {
					return result.getString("count");
				} 
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return "0";
	}

	public Student findById(Long regnumber) { 
		Connection conn = null;
		Student student= new Student();
		try {
			conn = dbConnection.connect();
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} catch (SQLException e1) {
			e1.printStackTrace();
		} 
		try { 
			PreparedStatement statement; 
			statement = conn.prepareStatement("SELECT * FROM student WHERE regnumber=? LIMIT 1");
			statement.setLong(1, regnumber); 
			ResultSet result = statement.executeQuery();
			while (result.next()) {   
				student.setRegnumber(result.getLong("regnumber"));
				student.setName(result.getString("name"));
				student.setAge(result.getInt("age"));
				student.setGender(result.getString("gender"));
				student.setGrade(result.getString("grade"));
				student.setStream(result.getString("stream")); 
				student.setEmail(result.getString("email"));
				student.setContactno(result.getString("contactno"));  
				student.setAddress(result.getString("address"));  
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return student;
	} 
}
