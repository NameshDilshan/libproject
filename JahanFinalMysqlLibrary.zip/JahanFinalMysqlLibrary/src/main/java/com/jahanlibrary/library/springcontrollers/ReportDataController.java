package com.jahanlibrary.library.springcontrollers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jahanlibrary.library.dbscripts.IssueAndReturnQueries;
import com.jahanlibrary.library.springentities.Issueandreturn;
 

@RestController	
public class ReportDataController {

	@Autowired
	private IssueAndReturnQueries issueAndReturnQueries;
	
	@PostMapping("/getData")
	public List<Issueandreturn> getReportSearchData(
			@RequestParam(name = "start", required = false, defaultValue = "1989-02-05") String startDate,
			@RequestParam(name = "end", required = false, defaultValue = "2025-02-05") String endDate,
			@RequestParam(name = "intbooknumb", required = false, defaultValue = "%") String intbooknumb,
			@RequestParam(name = "studentregnumber", required = false, defaultValue = "%") String studentregnumber
			){ 
		return issueAndReturnQueries.getData(startDate, endDate, intbooknumb, studentregnumber);
	}
}
