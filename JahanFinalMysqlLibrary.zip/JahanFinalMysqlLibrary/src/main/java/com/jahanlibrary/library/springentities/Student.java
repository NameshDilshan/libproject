package com.jahanlibrary.library.springentities;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Data;
 
@Entity
@Data
public class Student {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long regnumber;
	private String name;
	private Integer age;
	private String gender;
	private String grade;
	private String stream; 
	private String email;
	private String contactno;  
	private String address;
	
}
