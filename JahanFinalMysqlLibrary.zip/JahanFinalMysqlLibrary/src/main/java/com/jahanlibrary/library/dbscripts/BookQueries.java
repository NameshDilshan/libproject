package com.jahanlibrary.library.dbscripts;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.jahanlibrary.library.configuratons.Dbconnection;
import com.jahanlibrary.library.springentities.Book;

@Component
public class BookQueries {

	@Autowired
	private Dbconnection dbConnection;
	
	public List<Book> findAll() {
		String sql = "SELECT * FROM book";
		Connection conn = null;
		try {
			conn = dbConnection.connect();
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		Statement statement;
		List<Book> bookList = new ArrayList<Book>();
		try {
			statement = conn.createStatement();
			ResultSet result = statement.executeQuery(sql);
			while (result.next()) { 
				Book book= new Book();
				book.setIntbooknumb(result.getLong("intbooknumb"));
				book.setName(result.getString("name"));
				book.setAuthorname(result.getString("authorname"));
				book.setPublishedyear(result.getInt("publishedyear"));
				book.setPublisher(result.getString("publisher"));
				book.setBookrowno(result.getString("bookrowno"));
				book.setBookcount(result.getString("bookcount"));
				book.setPagecount(result.getString("pagecount"));
				bookList.add(book);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return bookList;
	}

	public void save(Book book) {
		try {
			Connection conn = null;
			try {
				conn = dbConnection.connect();
			} catch (ClassNotFoundException e1) {
				e1.printStackTrace();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			PreparedStatement statement;
			String sql = "INSERT INTO book  (`intbooknumb`, `name`, `authorname`, `publishedyear`, `publisher`, `bookrowno`, `bookcount` , `pagecount`) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
			statement = conn.prepareStatement(sql);
			statement.setLong(1, book.getIntbooknumb());
			statement.setString(2, book.getName());
			statement.setString(3, book.getAuthorname());
			statement.setInt(4, book.getPublishedyear());
			statement.setString(5, book.getPublisher());
			statement.setString(6, book.getBookrowno());
			statement.setString(7, book.getBookcount());
			statement.setString(8, book.getPagecount());
			statement.executeUpdate(); 
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void update(Book book) { 
		try {
			String sql = "UPDATE book SET name=?, authorname=?, publishedyear=? , publisher=?, bookrowno=?, bookcount=? , pagecount=? WHERE intbooknumb=?";
			Connection conn = null;
			try {
				conn = dbConnection.connect();
			} catch (ClassNotFoundException e1) {
				e1.printStackTrace();
			} catch (SQLException e1) {
				e1.printStackTrace();
			} 
			PreparedStatement statement;
			statement = conn.prepareStatement(sql);
			statement.setString(1, book.getName());
			statement.setString(2, book.getAuthorname());
			statement.setInt(3, book.getPublishedyear());
			statement.setString(4, book.getPublisher());
			statement.setString(5, book.getBookrowno());
			statement.setString(6, book.getBookcount());  
			statement.setString(7, book.getPagecount());  
			statement.setLong(8, book.getIntbooknumb());  
			statement.executeUpdate(); 
		} catch (Exception e) {
			e.printStackTrace();
		}   
	}
	
	public boolean existsById(Long intbooknumb) { 
		Connection conn = null;
		try {
			conn = dbConnection.connect();
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		Statement statement; 
		try {
			statement = conn.createStatement();
			ResultSet result = statement.executeQuery("SELECT * FROM book where intbooknumb = "+intbooknumb+"");
			while (result.next()) {
				if(result.getString(1).isEmpty()) {
					return false;
				}else {
					return true;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	} 
	
	public void deleteById(Long intbooknumb) {
		try { 
			Connection conn = null;
			try {
				conn = dbConnection.connect();
			} catch (ClassNotFoundException e1) {
				e1.printStackTrace();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			PreparedStatement statement; 
			statement = conn.prepareStatement("DELETE FROM book WHERE intbooknumb=?");
			statement.setLong(1, intbooknumb); 
			statement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}   
	}

	public String count() { 
		Connection conn = null;
		try {
			conn = dbConnection.connect();
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		Statement statement;
		try {
			statement = conn.createStatement();
			ResultSet result = statement.executeQuery("SELECT count(*) FROM book ");
			while (result.next()) {
				if(result.getString("count(*)").isEmpty()) {
					return result.getString("count(*)");
				} 
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return "0";
	}
	
	public Book findById(Long intbooknumb) { 
		Connection conn = null;
		Book book= new Book();
		try {
			conn = dbConnection.connect();
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} catch (SQLException e1) {
			e1.printStackTrace();
		} 
		try { 
			PreparedStatement statement; 
			statement = conn.prepareStatement("SELECT * FROM book WHERE intbooknumb=? LIMIT 1");
			statement.setLong(1, intbooknumb); 
			ResultSet result = statement.executeQuery();
			while (result.next()) {  
				book.setIntbooknumb(result.getLong("intbooknumb"));
				book.setName(result.getString("name"));
				book.setAuthorname(result.getString("authorname"));
				book.setPublishedyear(result.getInt("publishedyear"));
				book.setPublisher(result.getString("publisher"));
				book.setBookrowno(result.getString("bookrowno"));
				book.setBookcount(result.getString("bookcount"));
				book.setPagecount(result.getString("pagecount"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return book;
	} 
} 