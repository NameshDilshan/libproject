package com.jahanlibrary.library.configuratons;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.springframework.stereotype.Component;

@Component
public class Dbconnection { 
	public Connection connect() throws ClassNotFoundException, SQLException { 
			Class.forName("com.mysql.cj.jdbc.Driver");
			return DriverManager.getConnection( "jdbc:mysql://localhost:3306/jehanlibrary", "root", "mysql");  
	} 
}
