package com.jahanlibrary.library;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JahanApplication {

	public static void main(String[] args) {
		SpringApplication.run(JahanApplication.class, args);
	}

}
