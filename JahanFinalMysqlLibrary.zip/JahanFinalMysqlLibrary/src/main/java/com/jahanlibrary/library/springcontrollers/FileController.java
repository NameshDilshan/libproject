package com.jahanlibrary.library.springcontrollers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.jahanlibrary.library.dbscripts.BookQueries;
import com.jahanlibrary.library.dbscripts.IssueAndReturnQueries;
import com.jahanlibrary.library.dbscripts.StudentQueries;
import com.jahanlibrary.library.springentities.Book;
import com.jahanlibrary.library.springentities.Issueandreturn;
import com.jahanlibrary.library.springentities.Student;


@Controller
public class FileController {

	@Autowired
	private BookQueries bookQueries;
	
	@Autowired
	private StudentQueries studentQueries; 
	
	@Autowired 
	private IssueAndReturnQueries issueReturnQueries;
	
	@GetMapping("/issueBook")
	public String issueBook(Model model) {
		model.addAttribute("issueandreturn", new Issueandreturn());
		model.addAttribute("issueandreturns", issueReturnQueries.findAll());
		model.addAttribute("books", bookQueries.findAll());
		model.addAttribute("students", studentQueries.findAll());
		return "issueBook.jsp";
	}
	
	@GetMapping("/returnBook")
	public String returnBook(Model model) {
		model.addAttribute("issueandreturn", new Issueandreturn());
		model.addAttribute("issueandreturns", issueReturnQueries.findAll());
		model.addAttribute("books", bookQueries.findAll());
		model.addAttribute("students", studentQueries.findAll());
		return "returnBook.jsp";
	}
	
	@GetMapping("/")
	public String home(Model model) { 
		model.addAttribute("book", new Book());
		model.addAttribute("books", bookQueries.findAll());
		return "bookdashboard.jsp";
	}
	
	@GetMapping("/student")
	public String student(Model model) {
		model.addAttribute("student", new Student());
		model.addAttribute("students", studentQueries.findAll());
		return "studentdashboard.jsp";
	}
	
	@GetMapping("/book")
	public String book(Model model) {
		model.addAttribute("book", new Book());
		model.addAttribute("books", bookQueries.findAll());
		return "bookdashboard.jsp";
	}
	
	@GetMapping("/bookReport")
	public String bookIssueReport(Model model) { 
		model.addAttribute("books", bookQueries.findAll());
		model.addAttribute("students", studentQueries.findAll());
		return "bookIssueReport.jsp";
	}
	
	@GetMapping("/paymentReport")
	public String studentPaymentsReport(Model model) { 
		model.addAttribute("books", bookQueries.findAll());
		model.addAttribute("students", studentQueries.findAll());
		return "studentPaymentsReport.jsp";
	}
	
}
