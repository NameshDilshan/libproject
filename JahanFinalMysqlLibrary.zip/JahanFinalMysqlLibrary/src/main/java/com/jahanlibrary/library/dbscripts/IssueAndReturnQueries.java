package com.jahanlibrary.library.dbscripts;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.jahanlibrary.library.configuratons.Dbconnection;
import com.jahanlibrary.library.springentities.Issueandreturn;

@Component
public class IssueAndReturnQueries {

	@Autowired
	private Dbconnection dbConnection;
	
	public List<Issueandreturn> findAll() {
		String sql = " SELECT * from issueandreturn; ";
		Connection conn = null;
		try {
			conn = dbConnection.connect();
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		Statement statement;
		List<Issueandreturn> issueandreturnList = new ArrayList<Issueandreturn>();
		try {
			statement = conn.createStatement();
			ResultSet result = statement.executeQuery(sql);
			while (result.next()) {
				Issueandreturn issueandreturn = new Issueandreturn();
				issueandreturn.setId(result.getLong("id"));
				issueandreturn.setIssuedate(result.getString("issuedate"));
				issueandreturn.setDuedate(result.getString("duedate")); 
				issueandreturn.setReturneddate(result.getString("returneddate")); 
				issueandreturn.setFinepayment(result.getString("finepayment"));
				issueandreturn.setStudentregnumber(result.getString("studentregnumber"));
				issueandreturn.setStudentname(result.getString("studentname"));
				issueandreturn.setIntbooknumb(result.getString("intbooknumb"));
				issueandreturn.setBookname(result.getString("bookname"));
				issueandreturnList.add(issueandreturn);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return issueandreturnList;
	}

	public void save(Issueandreturn issueandreturn) {
		try {
			Connection conn = null;
			try {
				conn = dbConnection.connect();
			} catch (ClassNotFoundException e1) {
				e1.printStackTrace();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			String sql = "INSERT INTO issueandreturn ( `issuedate`, `duedate`, `returneddate`, `finepayment`, `studentregnumber`, `studentname`, `intbooknumb`, `bookname`) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?)";
			PreparedStatement statement = conn.prepareStatement(sql);
			statement.setString(1, issueandreturn.getIssuedate());
			statement.setString(2, issueandreturn.getDuedate());
			statement.setString(3, issueandreturn.getReturneddate());
			statement.setString(4, issueandreturn.getFinepayment());
			statement.setString(5, issueandreturn.getStudentregnumber());
			statement.setString(6, issueandreturn.getStudentname());
			statement.setString(7, issueandreturn.getIntbooknumb());
			statement.setString(8, issueandreturn.getBookname());
			statement.executeUpdate(); 
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void update(Issueandreturn issueandreturn) {
		try {
			String sql = "UPDATE issueandreturn SET issuedate=?, duedate=?, returneddate=? , finepayment=?, studentregnumber=?, studentname=? , intbooknumb=?, bookname=? WHERE id=?";
			Connection conn = null;
			try {
				conn = dbConnection.connect();
			} catch (ClassNotFoundException e1) {
				e1.printStackTrace();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			PreparedStatement statement;
			statement = conn.prepareStatement(sql);
			statement.setString(1, issueandreturn.getIssuedate());
			statement.setString(2, issueandreturn.getDuedate());
			statement.setString(3, issueandreturn.getReturneddate());
			statement.setString(4, issueandreturn.getFinepayment());
			statement.setString(5, issueandreturn.getStudentregnumber());
			statement.setString(6, issueandreturn.getStudentname());
			statement.setString(7, issueandreturn.getIntbooknumb());
			statement.setString(8, issueandreturn.getBookname());
			statement.setLong(9, issueandreturn.getId());
			statement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public boolean existsById(Long id) {
		Connection conn = null;
		try {
			conn = dbConnection.connect();
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		Statement statement;
		try {
			statement = conn.createStatement();
			ResultSet result = statement.executeQuery("SELECT * FROM issueandreturn where id = " + id + "");
			while (result.next()) {
				if (result.getString(1).isEmpty()) {
					return false;
				} else {
					return true;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	public Issueandreturn findById(Long id) {
		Connection conn = null;
		try {
			conn = dbConnection.connect();
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		Statement statement;
		Issueandreturn issueandreturn = new Issueandreturn();
		try {
			statement = conn.createStatement();
			ResultSet result = statement.executeQuery("SELECT * FROM issueandreturn where id = " + id + " LIMIT 1 ");
			while (result.next()) {
				issueandreturn.setId(result.getLong("id"));
				issueandreturn.setIssuedate(result.getString("issuedate"));
				issueandreturn.setDuedate(result.getString("duedate"));
				issueandreturn.setReturneddate(result.getString("returneddate"));
				issueandreturn.setFinepayment(result.getString("finepayment"));
				issueandreturn.setStudentregnumber(result.getString("studentregnumber"));
				issueandreturn.setStudentname(result.getString("studentname"));
				issueandreturn.setIntbooknumb(result.getString("intbooknumb"));
				issueandreturn.setBookname(result.getString("bookname"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return issueandreturn;
	}

	public void deleteById(Long id) {
		try {
			Connection conn = null;
			try {
				conn = dbConnection.connect();
			} catch (ClassNotFoundException e1) {
				e1.printStackTrace();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			PreparedStatement statement = conn.prepareStatement("DELETE FROM issueandreturn WHERE id=?");
			statement.setLong(1, id);
			statement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public List<Issueandreturn> getData(String startDate, String endDate, String intbooknumb, String studentregnumber) {
		String sql = " SELECT * FROM Issueandreturn WHERE issuedate BETWEEN '" + startDate + "' AND '" + endDate + "' "
				+ " AND intbooknumb LIKE '" + intbooknumb + "' AND studentregnumber LIKE '" + studentregnumber + "' ; ";
		Connection conn = null;
		try {
			conn = dbConnection.connect();
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		Statement statement;
		List<Issueandreturn> issueandreturns = new ArrayList<Issueandreturn>();
		try {
			statement = conn.createStatement();
			ResultSet result = statement.executeQuery(sql);
			while (result.next()) {
				Issueandreturn issueandreturn = new Issueandreturn();
				issueandreturn.setId(result.getLong("id"));
				issueandreturn.setIssuedate(result.getString("issuedate"));
				issueandreturn.setDuedate(result.getString("duedate"));
				issueandreturn.setReturneddate(result.getString("returneddate"));
				issueandreturn.setFinepayment(result.getString("finepayment"));
				issueandreturn.setStudentregnumber(result.getString("studentregnumber"));
				issueandreturn.setStudentname(result.getString("studentname"));
				issueandreturn.setIntbooknumb(result.getString("intbooknumb"));
				issueandreturn.setBookname(result.getString("bookname"));
				issueandreturns.add(issueandreturn);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return issueandreturns;
	}
}