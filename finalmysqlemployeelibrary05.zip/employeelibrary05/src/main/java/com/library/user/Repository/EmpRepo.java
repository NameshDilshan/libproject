package com.library.user.Repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.library.user.Entity.Emp;
import com.library.user.database.Db;

//public interface EmpRepository extends JpaRepository<Emp, Long>{
@Component
public class EmpRepo{

	public List<Emp> findAll() {
		String sql = "SELECT * FROM emp";
		Db db = new Db();
		Connection conn = db.getConnection();
		Statement statement;
		List<Emp> userList = new ArrayList<Emp>();
		try {
			statement = conn.createStatement();
			ResultSet result = statement.executeQuery(sql);
			while (result.next()) { 
				Emp user= new Emp();
				user.setEmpcode(result.getLong("empcode"));
				user.setName(result.getString("name"));
				user.setAge(result.getInt("age"));
				user.setSection(result.getString("section"));
				user.setJobtitle(result.getString("jobtitle"));
				user.setGender(result.getString("gender"));
				user.setEmail(result.getString("email"));
				user.setMobile(result.getString("mobile"));  
				user.setAddress(result.getString("address"));  
				user.setIdnumber(result.getString("idnumber"));
				userList.add(user);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return userList;
	}

	public void save(Emp user) {
		try {
			Db db = new Db();
			Connection conn = db.getConnection();
			String sql = "INSERT INTO emp  (`empcode`,`name`,`age`,`section`,`jobtitle`,`gender`,`email`,`mobile`, `address`,`idnumber` ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
			PreparedStatement statement = conn.prepareStatement(sql);
			statement.setLong(1, user.getEmpcode());
			statement.setString(2, user.getName());
			statement.setInt(3, user.getAge());
			statement.setString(4, user.getSection());
			statement.setString(5, user.getJobtitle());
			statement.setString(6, user.getGender()); 
			statement.setString(7, user.getEmail());
			statement.setString(8, user.getMobile());
			statement.setString(9, user.getAddress());
			statement.setString(10, user.getIdnumber());
			int rowsInserted = statement.executeUpdate();
			if (rowsInserted > 0) {
			    System.out.println("A new Emp inserted successfully!");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void update(Emp user) { 
		try {
			String sql = "UPDATE emp SET name=?, age=?, section=? , jobtitle=?, gender=?, email=?, mobile=?, address=?, idnumber=? WHERE empcode=?";
			Db db = new Db();
			Connection conn = db.getConnection();
			PreparedStatement statement;
			statement = conn.prepareStatement(sql);
			statement.setString(1, user.getName());
			statement.setInt(2, user.getAge());
			statement.setString(3, user.getSection());
			statement.setString(4, user.getJobtitle());
			statement.setString(5, user.getGender());
			statement.setString(6, user.getEmail());  
			statement.setString(7, user.getMobile());
			statement.setString(8, user.getAddress());
			statement.setString(9, user.getIdnumber());  
			statement.setLong(10, user.getEmpcode()); 
			int rowsUpdated = statement.executeUpdate();
			if (rowsUpdated > 0) {
			    System.out.println("An existing emp was updated successfully!");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}   
	}
	
	public boolean existsById(Long empcode) {
		String sql = "SELECT * FROM emp where empcode = "+empcode+"";
		Db db = new Db();
		Connection conn = db.getConnection();
		Statement statement; 
		try {
			statement = conn.createStatement();
			ResultSet result = statement.executeQuery(sql);
			while (result.next()) {
				if(result.getString(1).isEmpty()) {
					return false;
				}else {
					return true;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	} 
	
	public void deleteById(Long empcode) {
		try { 
			Db db = new Db();
			Connection conn = db.getConnection();
			String sql = "DELETE FROM emp WHERE empcode=?";
			 
			PreparedStatement statement = conn.prepareStatement(sql);
			statement.setLong(1, empcode); 
			int rowsDeleted = statement.executeUpdate();
			if (rowsDeleted > 0) {
			    System.out.println("Emp Deleted successfully!");
			} 
		} catch (Exception e) {
			e.printStackTrace();
		}   
	}
	
	public String count() {
		String sql = "SELECT count(*) FROM emp ";
		Db db = new Db();
		Connection conn = db.getConnection();
		Statement statement;
		try {
			statement = conn.createStatement();
			ResultSet result = statement.executeQuery(sql);
			while (result.next()) {
				if(result.getString("count(*)").isEmpty()) {
					return result.getString("count(*)");
				} 
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return "0";
	}

}
