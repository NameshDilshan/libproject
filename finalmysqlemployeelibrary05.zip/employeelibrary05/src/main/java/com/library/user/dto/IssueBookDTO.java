package com.library.user.dto;

import lombok.Data;

@Data
public class IssueBookDTO {

//	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String loandate;
	private String duedate;
	private String returneddate;
	private String fine;
	
	private String userno;
	private String username;
	private String bookid;
	private String bookname;
	
	
}
