package com.library.user.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.library.user.Entity.IssueBook;
import com.library.user.Repository.IssueBookRepo;

@Controller
public class IssueBookController {

	@Autowired
	private IssueBookRepo issueBookRepo;
	
	@PostMapping("/loanSave")
	public String loanSave(@ModelAttribute("loan") IssueBook issueBook, Model model) { 
		if(issueBookRepo.existsById(issueBook.getId())) {
			issueBookRepo.update(issueBook);
		}else {
			issueBookRepo.save(issueBook);
		}
		if(!issueBook.getReturneddate().isEmpty()) {
			return "redirect:/return";
		}
		return "redirect:/loan"; 
	}
	
	@DeleteMapping("/loans/{id}")
	@ResponseBody
	public Boolean deleteLoan(@PathVariable Long id , Model model) {  
		if(issueBookRepo.existsById(id)) {
			issueBookRepo.deleteById(id); 
			System.out.println(" Loan Deleted Successfully  ID : "+ id);
			return Boolean.TRUE;
		} 
		return Boolean.FALSE;
	} 
	
}
