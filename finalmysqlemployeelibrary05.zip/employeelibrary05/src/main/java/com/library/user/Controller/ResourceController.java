/**
 * 
 */
package com.library.user.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.library.user.Entity.Book;
import com.library.user.Entity.Emp;
import com.library.user.Entity.IssueBook; 
import com.library.user.Repository.BookRepo;
import com.library.user.Repository.EmpRepo;
import com.library.user.Repository.IssueBookRepo;

@Controller
public class ResourceController {

	@Autowired
	private BookRepo bookRepo; 
	@Autowired
	private EmpRepo empRepo; 
	@Autowired
	private IssueBookRepo issueBookRepo;
	
	@GetMapping("/")
	public String getMainDashboard(Model model) { 
		model.addAttribute("userCount", empRepo.count());
		model.addAttribute("bookCount", bookRepo.count());
		return "index.jsp";
	}
	
	@GetMapping("/book")
	public String book(Model model) {
		model.addAttribute("book", new Book());
		model.addAttribute("bookList", bookRepo.findAll());
		return "book.jsp";
	}
	
	@GetMapping("/user")
	public String user(Model model) {
		model.addAttribute("user", new Emp());
		model.addAttribute("userList", empRepo.findAll());
		return "user.jsp";
	}
	
	@GetMapping("/loan")
	public String loan(Model model) {
		model.addAttribute("loan", new IssueBook());
		model.addAttribute("loanList", issueBookRepo.findAll());
		model.addAttribute("books", bookRepo.findAll());
		model.addAttribute("users", empRepo.findAll());
		return "loan.jsp";
	}
	
	@GetMapping("/return")
	public String returnBook(Model model) {
		model.addAttribute("loan", new IssueBook());
		model.addAttribute("loanList", issueBookRepo.findAll());
		model.addAttribute("books", bookRepo.findAll());
		model.addAttribute("users", empRepo.findAll());
		return "return.jsp";
	}
	
	
//	@GetMapping("/returnBookManagementDashboard")
//	public String getReturnBookManagementDashboard(Model model) {
//		model.addAttribute("loan", new Loan());
//		model.addAttribute("loanList", loanRepo.findAll());
//		model.addAttribute("books", bookRepo.findAll());
//		model.addAttribute("users", empRepo.findAll());
//		return "returnBookManagementDashboard.jsp";
//	}
	
	@GetMapping("/bookLoanReport")
	public String getBookLoanReport(Model model) { 
		model.addAttribute("books", bookRepo.findAll());
		model.addAttribute("users", empRepo.findAll());
		return "reports/bookLoanReport.jsp";
	}
	
	@GetMapping("/userFineReport")
	public String getEmpFineReport(Model model) { 
		model.addAttribute("books", bookRepo.findAll());
		model.addAttribute("users", empRepo.findAll());
		return "reports/userFineReport.jsp";
	}
	
}
